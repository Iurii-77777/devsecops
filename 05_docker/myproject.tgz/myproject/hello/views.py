from django.http import HttpResponse

def home(request):
    return HttpResponse("<h1>Hello, Docker! Это заглушка Django приложения.</h1>")

